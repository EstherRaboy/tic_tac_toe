package com.example.XO;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.example.submarines.R;

public class MainActivity extends AppCompatActivity {
    FrameLayout frameLayout;
    BoardGame boardGame;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        frameLayout=findViewById(R.id.frame);
        boardGame = new BoardGame(this);
        frameLayout.addView(boardGame);
    }

    public void startGame(View view){
        boardGame.startGame();
    }
}