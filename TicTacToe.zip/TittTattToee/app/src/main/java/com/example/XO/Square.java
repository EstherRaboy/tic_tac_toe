package com.example.XO;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;

public class Square {
    BoardGame boardGame;
    float x,y,w,h;//top left
    int state=0;
    Paint p;
    float phi = (float) 1.618033988749895;
    public Square(BoardGame boardGame, float x, float y, float w, float h, int state)
    {
        this.x = x;
        this.y = y;
        this.boardGame = boardGame;
        p = new Paint();
        this.w = w;
        this.h = h;
        this.state = state;
    }

    public void drawStroke(Canvas canvas)
    {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(10);
        p.setColor(Color.rgb(91,152,210));
        canvas.drawRect(x,y,x+w,y+h,p);
    }

    public void draw(Canvas canvas)
    {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.WHITE);
        canvas.drawRect(x,y,x+w,y+h,p);
        drawStroke(canvas);
        if (this.state == 1){
            p.setColor(Color.RED);
            p.setStyle(Paint.Style.STROKE);
            //three code lines for drawing "x" by to lines
            p.setStrokeWidth(w*(phi-1)/2-w*(phi-1)*(phi-1)/2);
            canvas.drawLine((float)(x+0.25*w),(float)(y+0.25*h),(float)(x+0.75*w),(float)(y+0.75*h),p);
            canvas.drawLine((float)(x+0.75*w),(float)(y+0.25*h),(float)(x+0.25*w),(float)(y+0.75*h),p);
        }else if(this.state == 2){
            Log.d("seem", "drew 2");
            p.setColor(Color.BLACK);
            p.setStyle(Paint.Style.FILL);
            canvas.drawCircle(x+w/2,y+h/2,w*(phi-1)/2,p);
            p.setColor(Color.WHITE);
            canvas.drawCircle(x+w/2,y+h/2,w*(phi-1)*(phi-1)/2,p);
        }
    }

    public float getW(){return w;}
    public float getH(){return h;}
}
