package com.example.XO;

import android.content.Context;
import android.graphics.Canvas;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.submarines.R;

public class BoardGame extends View {
    final int size = 3;
    Square[][] squares;
    int[][] states = new int[size][size];
    Context context;
    int turn = 1;   //X=1 O=2
    Boolean runnin = true;
    TextView textView;

    public BoardGame(Context context) {
        super(context);
        this.context = context;
        squares = new Square[size][size];
        textView = findViewById(R.id.textView);
    }

    public void startGame() {
        states = new int[size][size];
        turn = 1;   //X=1 O=2
        runnin = true;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Log.d("seem", "onDraw");
        super.onDraw(canvas);
        drawBoard(canvas);
    }

    public void drawBoard(Canvas canvas) {
        int h = canvas.getWidth() / size;
        int w = canvas.getWidth() / size;
        for (int i = 0; i < squares.length; i++) {
            for (int j = 0; j < squares.length; j++) {
                squares[i][j] = new Square(this, j * w, i * h, w, h, states[i][j]);
                squares[i][j].draw(canvas);
            }
        }
        Log.d("seem", "drew board");

    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        for (int i = 0; i < squares.length; i++) {
            for (int j = 0; j < squares.length; j++) {
                if (e.getX() > j * squares[i][j].getW() && e.getX() < (j + 1) * squares[i][j].getW()) {
                    if (e.getY() > i * squares[i][j].getH() && e.getY() < (i + 1) * squares[i][j].getH()) {
                        if (states[i][j] == 0 && runnin)
                        {
                            states[i][j] = turn;
                            if(isVictory(turn) == turn)
                            {
                                showResult("X Won!");
                                runnin = false;
                            }
                            turn = (turn) % 2 + 1;

                            makeMove();
                            if(isVictory(turn) == turn)
                            {
                                showResult("O Won!");
                                runnin = false;
                            }
                            if(hasEmptySquares() == false)
                            {
                                showResult("Draw...");
                                runnin = false;
                            }
                            turn = (turn) % 2 + 1;

                            invalidate();
                            return true;
                        }
                    }
                }
            }
        }
        return true;
    }

    private void showResult(String result)
    {
        Toast toast=Toast.makeText(context, result,Toast.LENGTH_SHORT);
        toast.show();
    }

    private int isVictory(int currentTurn) {
        //horizontal
        for (int col = 0; col < 3; col++) {
            if (states[0][col] == currentTurn && states[1][col] == currentTurn && states[2][col] == currentTurn) {
                return currentTurn;
            }
        }

        //vertical
        for (int row = 0; row < 3; row++) {
            if (states[row][0] == currentTurn && states[row][1] == currentTurn && states[row][2] == currentTurn) {
                return currentTurn;
            }
        }

        //diagonal
        if ((states[0][0] == currentTurn && states[1][1] == currentTurn && states[2][2] == currentTurn) ||
                (states[2][0] == currentTurn && states[1][1] == currentTurn && states[0][2] == currentTurn)) {
            return currentTurn;
        }
        return 0;
    }

    private boolean hasEmptySquares()
    {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++)
            {
                if(states[row][col] == 0)
                {
                    return true;
                }
            }
        }
        return false;
    }

    private int evaluateBoard(int currentTurn)
    {
        int victor = this.isVictory(currentTurn);
        if(victor > 0)
        {
            if(victor % 2 == 0)
                return 1;
            else
                return -1;
        }
        return 0;
    }

    private  int minimax(int currentTurn)
    {
        int rate = evaluateBoard(currentTurn);
        if(rate == 1 || rate == -1 || hasEmptySquares() == false)
        {
            return rate;
        }
        int bestRate = currentTurn % 2 == 0 ? -10 : 10;
        for (int row = 0; row < 3; row++)
        {
            for (int col = 0; col < 3; col++)
            {
                if(states[row][col] == 0)
                {
                    states[row][col] = currentTurn;
                    bestRate = currentTurn % 2 == 0 ?
                            Math.max(bestRate, minimax(currentTurn % 2 + 1)) :
                            Math.min(bestRate, minimax(currentTurn % 2 + 1));
                    states[row][col] = 0;
                }
            }
        }
        return bestRate;
    }

    private void makeMove()
    {
        int bestRate = -10, bestRow = -1, bestCol = -1;
        for (int row = 0; row < 3; row++)
        {
            for (int col = 0; col < 3; col++)
            {
                if(states[row][col] == 0)
                {
                    states[row][col] = turn;
                    int moveRate = minimax(turn % 2 + 1);
                    states[row][col] = 0;
                    if(moveRate > bestRate)
                    {
                        bestRate = moveRate;
                        bestRow = row;
                        bestCol = col;
                    }
                }
            }
        }
        if(bestRow > -1 && bestCol > -1)
        {
            states[bestRow][bestCol] = turn;
        }
    }
}